/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.config;

import com.movie.entity.Actor;
import com.movie.entity.Category;
import com.movie.entity.Client;
import com.movie.entity.Country;
import com.movie.entity.Film;
import com.movie.entity.Ganre;
import com.movie.entity.Operator;
import com.movie.entity.Producer;
import com.movie.entity.Roles;
import com.movie.entity.Users;
import com.movie.repos.ActorRepository;
import com.movie.repos.CategoryRepository;
import com.movie.repos.ClientRepository;
import com.movie.repos.CountryRepository;
import com.movie.repos.FilmRepository;
import com.movie.repos.GanreRepository;
import com.movie.repos.OperatorRepository;
import com.movie.repos.ProducerRepository;
import com.movie.repos.RolesRepository;
import com.movie.repos.UsersRepository;
import java.util.Date;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 *
 * @author Root
 */
@Component
public class SetupDataLoader implements  ApplicationListener<ContextRefreshedEvent> {
    private boolean alreadySetup = false;

    @Autowired  private UsersRepository userRepository;
    @Autowired  private OperatorRepository operRepository;
    @Autowired  private ClientRepository clientRepository;
    @Autowired  private RolesRepository roleRepository;
    @Autowired private GanreRepository ganreRepository;
    @Autowired private CountryRepository countryRepository;
    @Autowired private CategoryRepository categoryRepository;
    @Autowired private ProducerRepository producerRepository;
    @Autowired private ActorRepository actorRepository;
    @Autowired private  FilmRepository filmRepository;
    
    
    @Autowired   private PasswordEncoder passwordEncoder;

    @Override
    @Transactional
    public void onApplicationEvent(ContextRefreshedEvent e) {
         if (alreadySetup) {
            return;
        }
        
         
         
        final Roles adminRole =  createRoleIfNotFound("Admin","ROLE_ADMIN");
        final Roles userRole = createRoleIfNotFound("Client","ROLE_USER");
        final Roles operRole = createRoleIfNotFound("Operator","ROLE_OPER");
        
        createUserIfNotFound("admin", "admin", "admin", adminRole);
        createOperIfNotFound("oper", "oper", "oper", operRole);
        createOperIfNotFound("oper", "oper", "oper", operRole);
        createClientIfNotFound("client","client","client",userRole);
        
        
        createGanreIfNotFound("Action");
        createGanreIfNotFound("Comedy");
        final Ganre ganre = createGanreIfNotFound("Adventures");
        
        createCountryIfNotFound("PL", "Poland");
        final Country USA =  createCountryIfNotFound("US", "United States");
        createCountryIfNotFound("UK", "English");
        
        final Category category = createCategoryIfNotFound("new","new", 20);
        createCategoryIfNotFound("normal","normal", 15);
        createCategoryIfNotFound("sale","sale", 10);
        
        final Producer producer = createProducerIfNotFound("Ewa","Ewart");
        final Actor actor= createActorIfNotFound("Jack","Nicholson");
        createActorIfNotFound("Marlon","Brando");
        createActorIfNotFound("Tom","Hanks");
        createActorIfNotFound("Clark","Gable");
        createActorIfNotFound("Daniel","Day-Lewis");
        createActorIfNotFound("Shon","Astin");
        createActorIfNotFound("Dominik","Monagan");
        createActorIfNotFound("Billie","Boyd");
        
        
        createFilmIfNotFound("Need for Speed ",category,USA,ganre,producer,actor,2001,"f1.jpg");
        createFilmIfNotFound("Tytanic",category,USA,ganre,producer,actor,2002,"f2.jpg");
        createFilmIfNotFound("Spider Man",category,USA,ganre,producer,actor,2003,"f3.jpg");
       
        alreadySetup = true;
        


    }
    
    
    @Transactional
    private final Roles createRoleIfNotFound(final String name, final String roleName) {
        Roles role = roleRepository.findByRoleName(roleName);
        if (role == null) {
            role = new Roles( roleName,name);
            role = roleRepository.save(role);
        }
        
        return role;
    }
    
    @Transactional
    private final Users createUserIfNotFound(final String login, final String name, final String password,Roles role) {
        Users user = userRepository.findByLogin(login).orElse(null);
        if (user == null) {
            user = new Users();
            user.setLastName(name);
            user.setPassword(passwordEncoder.encode(password));
            user.setLogin(login);
            user.setRole(role);
            user = userRepository.save(user);
        }
        
        return user;
    }
    @Transactional
    private final Users createOperIfNotFound(final String login, final String name, final String password,Roles role) {
        Operator user = operRepository.findByLogin(login);
        if (user == null) {
            user = new Operator();
            user.setLastName(name);
             user.setFirstName("demo");
            user.setPassword(passwordEncoder.encode(password));
            user.setLogin(login);
            user.setRole(role);
            user = operRepository.save(user);
        }
        
        return user;
    }
    @Transactional
    private final Users createClientIfNotFound(final String login, final String name, final String password,Roles role) {
        Client user = clientRepository.findClientByLogin(login);
        if (user == null) {
            user = new Client();
            user.setLastName(name);
            user.setFirstName("demo");
            user.setPassword(passwordEncoder.encode(password));
            user.setLogin(login);
            user.setRole(role);
            user = clientRepository.save(user);
        }
        
        return user;
    }
    
    
    @Transactional
    private final Ganre createGanreIfNotFound(final String name) {
        Ganre ganre = ganreRepository.findByName(name).orElse(null);
        if (ganre == null) {
            ganre = new Ganre(name);
            ganre = ganreRepository.save(ganre);
        }
        
        return ganre;
    }
    @Transactional
    private final Country createCountryIfNotFound(final String code,final String name) {
        Country country = countryRepository.findByCode(code).orElse(null);
        if (country == null) {
            country = new Country(code,name);
            country = countryRepository.save(country);
        }
        
        return country;
    }
    
    @Transactional
    private final Category createCategoryIfNotFound(final String code,final String name, final float cost) {
        Category category = categoryRepository.findByCode(code).orElse(null);
        if (category == null) {
            category = new Category(code,name,cost);
            category = categoryRepository.save(category);
        }
        
        return category;
    }
    
    
    @Transactional
    private final Producer createProducerIfNotFound(final String firstName,final String lastName) {
        Producer producer = producerRepository.findByFirtNameAndLastName(firstName, lastName).orElse(null);
        if (producer == null) {
            producer = new Producer(firstName,lastName);
            producer = producerRepository.save(producer);
        }
        
        return producer;
    }
    @Transactional
    private final Actor createActorIfNotFound(final String firstName,final String lastName) {
        Actor actor = actorRepository.findByFirtNameAndLastName(firstName, lastName).orElse(null);
        if (actor == null) {
            actor = new Actor(firstName,lastName);
            actor = actorRepository.save(actor);
        }
        
        return actor;
    }
    
    @Transactional
    private final Film createFilmIfNotFound(final String name,Category cat,Country country, Ganre ganre, 
            Producer producer, Actor actor, int year,String poster) {
        Film film = filmRepository.findByNameAndProducer(name, producer).orElse(null);
        if (film == null) {
            film = new Film();
            film.setName(name);
            film.getActors().add(actor);
            film.setProducer(producer);
            film.setYear(year);
            film.setGanre(ganre);
            film.setCategory(cat);
            film.setCountry(country);
            film.setAddDate(new Date());
            film.setAviable(5);
            film.setPoster("/uploads/"+poster);
            film = filmRepository.save(film);
        }
        
        return film;
    }
    
    
    
    @Bean
    public BCryptPasswordEncoder passwordEncoder() {
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        return bCryptPasswordEncoder;
    }




    
}
