/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.rest;

import com.movie.entity.Film;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Getter
@Setter
public class ResponseTransfer {
    String errorText;
    boolean error = false;
    List<Film> films;

    public ResponseTransfer(List<Film> films) {
        this.films = films;
        this.error = false;
    }
    public ResponseTransfer(List<Film> films,String error) {
        this.films = films;
        this.error = true;
        this.errorText = error;
                
    }

    public ResponseTransfer() {
        this.films = new ArrayList<>();
    }
    
    
    
}
