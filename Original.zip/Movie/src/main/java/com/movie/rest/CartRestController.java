/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.rest;

import com.movie.exception.CartException;
import com.movie.service.CartService;
import com.movie.util.CartSize;
import java.security.Principal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Root
 */
@RestController
@RequestMapping(value = "cart")
public class CartRestController {

    
        
    @Autowired CartService service;
    @Autowired CartSize carsSize;
    
     @RequestMapping(value = "/all", produces = MediaType.APPLICATION_JSON_VALUE,
            method ={POST,GET } )
    @ResponseBody
    public ResponseEntity<ResponseTransfer> getAll(Principal principal){
        ResponseTransfer res = new ResponseTransfer();
        res.getFilms().addAll(service.getCart(principal.getName()));
        return new ResponseEntity(res,HttpStatus.OK);
     }
    
    @RequestMapping(value = "/add/{id}", produces = MediaType.APPLICATION_JSON_VALUE,
            method ={POST,GET } )
    @ResponseBody
    public ResponseEntity<ResponseTransfer> addFilm(@PathVariable long id,Principal principal){
        ResponseTransfer res = new ResponseTransfer();
        try{
           service.addToCart(id,principal.getName());
        }catch(Exception ex){
            res.setError(true);
            if (ex instanceof org.springframework.dao.DataIntegrityViolationException){
                res.setErrorText("Film juz w koszyku");
            }else if (ex instanceof CartException){
                res.setErrorText(ex.getMessage());
            }
            else {
               res.setErrorText("Error! Contact your administration!");
            }
            
       }
        finally{
           res.getFilms().addAll(service.getCart(principal.getName()));
        }
        return new ResponseEntity(res,HttpStatus.OK);
    }
    
     @RequestMapping(value = "/del/{id}", produces = MediaType.APPLICATION_JSON_VALUE,
            method ={POST,GET } )
    @ResponseBody
    public ResponseEntity<ResponseTransfer> delFilm(@PathVariable long id,Principal principal){
        ResponseTransfer res = new ResponseTransfer();
        try{
           service.delFromCart(id,principal.getName());
        }catch(Exception ex){
            res.setError(true);
            if (ex instanceof org.springframework.dao.DataIntegrityViolationException){
                res.setErrorText("Film juz w koszyku");
            }else if (ex instanceof CartException){
                res.setErrorText(ex.getMessage());
            }
            else {
               res.setErrorText("Error! Contact your administration!");
            }
            
       }
        finally{
           res.getFilms().addAll(service.getCart(principal.getName()));
        }
        return new ResponseEntity(res,HttpStatus.OK);
    }
     @RequestMapping(value = "/clear", produces = MediaType.APPLICATION_JSON_VALUE,
            method ={POST,GET } )
    @ResponseBody
    public ResponseEntity<ResponseTransfer> clear(Principal principal){
        ResponseTransfer res = new ResponseTransfer();
        try{
           service.clearCart(principal.getName());
        }catch(Exception ex){
            res.setError(true);
             if (ex instanceof CartException){
                res.setErrorText(ex.getMessage());
            }
            else {
               res.setErrorText("Error! Contact your administration!");
            }
            
       }
        finally{
           res.getFilms().addAll(service.getCart(principal.getName()));
        }
        return new ResponseEntity(res,HttpStatus.OK);
    }
    /* @GetMapping(value = "/hello", produces = MediaType.APPLICATION_JSON_VALUE)
    
    @ResponseBody
    public ResponseEntity<ResponseTransfer> delFilm(){
        return new ResponseEntity(new ResponseTransfer(),HttpStatus.OK);
    }
    @ResponseBody
    public ResponseEntity<ResponseTransfer> clear(){
        return new ResponseEntity(new ResponseTransfer(),HttpStatus.OK);
    }
    
    @ResponseBody
    public ResponseEntity<ResponseTransfer> getCart(){
        return new ResponseEntity(new ResponseTransfer(),HttpStatus.OK);
    }

       */

}
