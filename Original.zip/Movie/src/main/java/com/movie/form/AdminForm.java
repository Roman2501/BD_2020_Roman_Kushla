/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.form;

import com.movie.util.USER_TYPE;
import java.io.Serializable;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Getter
@Setter
public class AdminForm  extends UserForm{

    public AdminForm(String firstName,String lastName, String login, String password, String confirmPassword) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.login = login;
        this.password = password;
        this.confirmPassword = confirmPassword;
        this.userType = USER_TYPE.ADMIN;
    }

    public AdminForm() {
        this.old = false;
        this.userType = USER_TYPE.ADMIN;
    }
    
   

 
}

