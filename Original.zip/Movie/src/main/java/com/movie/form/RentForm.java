/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.form;

import com.movie.entity.Rent;
import java.util.Calendar;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Getter
@Setter
public class RentForm {
    Date issueDate;
    Date closeDate;
    Rent rent;
    float money;
    float deposite;
    int days;
    long id;
    

    public RentForm(Rent rent) {
      if (rent!=null){
      this.rent = rent;
      this.id = rent.getId();
      this.issueDate = rent.getIssueDate();
      this.deposite = rent.getDeposite();
      calc();}
    }
    private void calc(){
        closeDate = new Date();
        long diff = closeDate.getTime() - issueDate.getTime();
        diff = diff / 1000 / 60 / 60 / 24;
        days = (int) diff;
        if (days==0) days=1;
          money = days*rent.getCost();
          money = money-deposite;
        }
    
        
        
    }
    
    
    
    
 
