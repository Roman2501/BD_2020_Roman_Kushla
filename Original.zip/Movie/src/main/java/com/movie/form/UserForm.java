/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.form;

import com.movie.util.USER_TYPE;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Getter
@Setter
public class UserForm {
    public USER_TYPE userType;
    public boolean old = true;
    public String firstName;
    public  String lastName;
    public  String login;
    public  String password;
    public  String confirmPassword;
    public String role;

    public UserForm(String firstName,String lastName, String login, String password, String confirmPassword) {
        this.firstName = firstName;
        this.lastName  = lastName;
        this.login = login;
        this.password = password;
        this.confirmPassword = confirmPassword;
    }
    
    public UserForm(String firstName,String lastName, String login) {
        this.firstName = firstName;
        this.lastName  = lastName;
        this.login = login;
    }

    public UserForm() {
        this.old = false;
    }

    
}


