/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.form;

import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Getter
@Setter
public class PasswordForm {

    private String login;
    private String password;
    private String confirmPassword;

    public PasswordForm(String login) {
        this.login = login;
    }

   

}

