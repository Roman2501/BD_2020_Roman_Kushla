/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.form;

import com.movie.util.USER_TYPE;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Getter
@Setter
public class OperatorForm extends UserForm {

    String phone;
    String note;

    public OperatorForm(String firstName, String lastName, String login, String password, String confirmPassword,
            String phone, String note) {
        super(firstName, lastName, login, password, confirmPassword);
        this.phone = phone;
        this.note = note;
        this.userType = USER_TYPE.OPER;

    }

    public OperatorForm(String firstName, String lastName, String login,
            String phone, String note) {
        setOld(true);
        setFirstName(firstName);
        setLastName(lastName);
        this.phone = phone;
        this.note = note;
        this.userType = USER_TYPE.OPER;

    }

    public OperatorForm() {
        setOld(false);
        this.userType = USER_TYPE.OPER;
    }

}
