/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.form;

import com.movie.util.USER_TYPE;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Getter
@Setter
public class ClientForm  extends UserForm{
    
    String phone;
    String note;
    String document;


    public ClientForm(String firstName,String lastName, String login, String password, String confirmPassword,
             String phone,String document, String note) {
        super(firstName,lastName,login,password,confirmPassword);
        this.phone = phone;
        this.note = note;
        this.document = document;
        this.userType = USER_TYPE.CLIENT;
        
    }
    public ClientForm(String firstName,String lastName, String login, 
        String phone,String document, String note) {
        setOld(true);
        setFirstName(firstName);
        setLastName(lastName);
        this.phone = phone;
         this.document = document;
        this.note = note;
        this.userType = USER_TYPE.CLIENT;
        
    }

    public ClientForm() {
        setOld(false);
        this.userType = USER_TYPE.CLIENT;
    }
    
    

    
     
}

