/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.service;

import com.movie.entity.Roles;
import com.movie.entity.Users;
import com.movie.repos.ClientRepository;
import com.movie.repos.OperatorRepository;
import com.movie.repos.RolesRepository;
import com.movie.repos.UsersRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Root
 */
@Service
public class AdminService {
    private static final Logger logger = LoggerFactory.getLogger(AdminService.class);

    @Autowired
    private UsersRepository userRepository;

    @Autowired
    private OperatorRepository operRepository;

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private RolesRepository roleRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    


    // Create User
    @Transactional
    public String createUser(String login, String firstName, String lastName, String password, String roleName) {
        String error = null;
        Users newUser = null;
        try {
            newUser = new Users();
            newUser.setLogin(login.toLowerCase());
            newUser.setFirstName(firstName);
            newUser.setLastName(lastName);
            newUser.setEnabled(true);
            newUser.setPassword(passwordEncoder.encode(password));
            Roles role = roleRepository.findByRoleName(roleName);
            newUser.setRole(role);
            newUser = userRepository.save(newUser);
        } catch (Exception e) {
            error = e.getLocalizedMessage();
        }
        return error;
    }

    // reset password
    @Transactional
    public String resetPassword(String login, String password) {
        String error = null;
        Users user = null;
        try {
            user = userRepository.findByLogin(login).orElse(null);
            if (user != null) {
                user.setPassword(passwordEncoder.encode(password));
                user = userRepository.save(user);
            }
        } // Other error!!
        catch (Exception e) {
            error = e.getLocalizedMessage();
        } // Other error!!
        return error;
    }

   
    


   

 
}
