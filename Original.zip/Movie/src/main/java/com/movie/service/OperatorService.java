/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.service;

import com.movie.entity.Operator;
import com.movie.entity.Rent;
import com.movie.entity.Roles;
import com.movie.entity.Users;
import com.movie.form.OperatorForm;
import com.movie.repos.ClientRepository;
import com.movie.repos.OperatorRepository;
import com.movie.repos.RentRepository;
import com.movie.repos.RolesRepository;
import com.movie.repos.UsersRepository;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Root
 */
@Service
public class OperatorService {
    private static final Logger logger = LoggerFactory.getLogger(OperatorService.class);

    @Autowired
    private UsersRepository userRepository;

    @Autowired
    private OperatorRepository operRepository;

    @Autowired
    private ClientRepository clientRepository;
    
    @Autowired 
    RentRepository rentRepository;

    @Autowired
    private RolesRepository roleRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Transactional
    public String createOperator(OperatorForm form) {
        String error = null;
        Operator newUser = null;
        try {
            newUser = new Operator();
            newUser.setLogin(form.getLogin().toLowerCase());
            newUser.setLastName(form.getLastName());
            newUser.setFirstName(form.getFirstName());
            newUser.setEnabled(true);
            newUser.setPassword(passwordEncoder.encode(form.getPassword()));
            Roles role = roleRepository.findByRoleName(form.getRole());
            newUser.setRole(role);
            newUser.setPhone(form.getPhone());
            newUser.setNote(form.getNote());
            newUser = operRepository.save(newUser);
        } catch (Exception e) {
            error = e.getMessage();
            logger.error(e.getMessage());
        }
        return error;
    }

    @Transactional
    public String updateOperator(OperatorForm form) {
        String error = null;
        Operator newUser = null;
        try {
            newUser =  operRepository.findByLogin(form.getLogin());
            if (newUser != null) {
                newUser.setLastName(form.getLastName());
                newUser.setFirstName(form.getFirstName());
                newUser.setPhone(form.getPhone());
                newUser.setNote(form.getNote());
                newUser = operRepository.save(newUser);
            }
        } catch (Exception e) {
            error = e.getLocalizedMessage();
            logger.error(e.getMessage());
        }
        return error;
    }
    
    
    public List<Operator> getOperators(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("lastName").ascending());
        return operRepository.findAllOpers(pageable);
    }
    
    
     public Operator getOperator(String login) {
        return operRepository.findByLogin(login);
    }
    
    public List<Rent> getActiveRentByOper(String login){
        Operator oper = operRepository.findByLogin(login);
        return rentRepository.findActiveRentByOper(oper);
    }
    
    public List<Rent> getAllRentByOper(int page,int size, String login){
        Operator oper = operRepository.findByLogin(login);
        Pageable pageable = PageRequest.of(page, size, Sort.by("returnDate").ascending());
        return rentRepository.findRentByOper(pageable,oper);
    }
     public Optional<Rent> getRentByID(long id){
         
        return rentRepository.findById(id);
    }
    
      // reset password
    public String resetPassword(String login, String password) {
        String error = null;
        Users user = null;
        try {
            user = userRepository.findByLogin(login).orElse(null);
            if (user != null) {
                user.setPassword(passwordEncoder.encode(password));
                user = userRepository.save(user);
            }
        } // Other error!!
        catch (Exception e) {
            error = e.getLocalizedMessage();
        } // Other error!!
        return error;
    }


}
