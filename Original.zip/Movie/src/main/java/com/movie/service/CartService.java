/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.service;

import com.movie.entity.*;

import com.movie.exception.CartException;
import com.movie.repos.CartRepository;
import com.movie.repos.CashRepository;
import com.movie.repos.OperatorRepository;
import com.movie.repos.FilmRepository;
import com.movie.repos.RentRepository;
import com.movie.util.CartSize;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Root
 */
@Service
public class CartService {
    @Autowired
    FilmRepository filmRepository;
    
    @Autowired 
    CartRepository cartRepository;
    @Autowired 
    RentRepository rentRepository;
    @Autowired 
    CashRepository cashRepository;
    
    @Autowired CartSize carsSize;
    
    @Autowired OperatorRepository operatorRepository;
    
    // przetwarzanie koszyka, zmniejszenie  czy zwiekszenie liczby
    
    // kiedy film w koszyku - dostepnosc jest mniejsza o 1
    
    
    
    public List<Film> getCart(String login){
        Operator oper = getOperator(login);
        List<Film> list = cartRepository.findByOperator(oper);
        carsSize.getFilms().clear();
        carsSize.getFilms().addAll(list);
        return list;
    }
    private Operator getOperator(String login){
          return operatorRepository.findByLogin(login);
    }
    
    @Transactional
    public void addToCart(long filmId,String login) throws Exception {
        Film film = filmRepository.findById(filmId).orElse(null);
        Operator oper = getOperator(login);
        if (film==null) throw new CartException("Film not found!");
        updateFilm(film,-1);
        addFilm(film,oper);
        List<Film> list = cartRepository.findByOperator(oper);
        carsSize.getFilms().clear();
        carsSize.getFilms().addAll(list);
        
        
    }
    @Transactional
    public void clearCart(String login)throws Exception{
                Operator oper = getOperator(login);
               cartRepository.findByOperator(oper).stream().forEach(film->{
               
               long i;
                   try {
                       i = delFilm(film,oper);
                       updateFilm(film, (int) i);
                   } catch (Exception ex) {
                       Logger.getLogger(CartService.class.getName()).log(Level.SEVERE, null, ex);
                   }
               
         });
          List<Film> list = cartRepository.findByOperator(oper);
        carsSize.getFilms().clear();
        carsSize.getFilms().addAll(list);
    }
    
    @Transactional
    public void delFromCart(long filmId,String login) throws Exception {
        Operator oper = getOperator(login);
        Film film = filmRepository.findById(filmId).orElse(null);
        if (film==null) throw new CartException("Film not found!");
        long i = delFilm(film, oper);
        updateFilm(film, (int) i);
          List<Film> list = cartRepository.findByOperator(oper);
        carsSize.getFilms().clear();
        carsSize.getFilms().addAll(list);
        
    }
    private void updateFilm(Film film,int i) throws Exception{
        int a = film.getAviable();
        if (a==0 && i<0) throw new CartException("Film unavailable for order!");
        a=a+i;
        film.setAviable(a);
        film = filmRepository.save(film);
    }
    private void addFilm(Film film, Operator oper )throws Exception{
        Cart cart = new Cart();
        cart.setOper(oper);
        cart.setFilm(film);
        cartRepository.save(cart);
    }
    private long delFilm(Film film, Operator oper )throws Exception{
        return cartRepository.deleteByFilmAndOper(film,oper);
    }
    
    @Transactional
    public Cash addToRent(String login, Client client, int days, float deposite) throws Exception {
          Operator oper = getOperator(login);
          List<Film> list = cartRepository.findByOperator(oper);
          if (list.size()==0) throw new CartException("Koszyk pusty!");
          float sum =  (float) list.stream().mapToDouble(f->f.getCategory().getCost()).sum();
          Rent rent = new Rent();
          rent.setDeposite(deposite);
          rent.setDays(days);
          rent.setClient(client);
          Date regDate = new Date();
          rent.setIssueDate(regDate);
          rent.getFilm().addAll(list);
          rent = rentRepository.save(rent);
          rent.setOperator(oper);
          rent.setCost(sum);
          rent.setBalance(0);
          Cash  cash = new Cash(rent,oper,regDate,deposite);
          cash = cashRepository.save(cash);
          cartRepository.deleteByOper(oper);
          carsSize.getFilms().clear();
          return cash;
    }
    @Transactional
    public Cash closeRent(long id, int days, float money,String login) throws Exception {
          Operator oper = getOperator(login);
          Rent rent = rentRepository.getOne(id);
          rent.setDays(days);
          Date regDate = new Date();
          rent.setReturnDate(regDate);
          rent.setBalance(money);
          rent = rentRepository.save(rent);
          rent.getFilm().forEach(f->{
              filmRepository.updateById(f.getId());
          });
          
          Cash  cash = new Cash(rent,oper,regDate,money);
          cash = cashRepository.save(cash);
          return cash;

    }
    
}
