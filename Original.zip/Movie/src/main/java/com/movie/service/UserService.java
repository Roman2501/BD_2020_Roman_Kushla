/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.service;

import com.movie.entity.Client;
import com.movie.entity.Users;
import com.movie.repos.RolesRepository;
import com.movie.repos.UsersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 *
 * @author Root
 */
@Service
public class UserService {
    
    @Autowired
    private RolesRepository roleRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired UsersRepository repository;
     public Users getUserByLogin(String login) {
        return repository.findByLogin(login).orElse(null);
    }
     
      // resetPassword
    public String resetPassword(String login,String password){
        String error=null;
         Users user = null;
        try {
            user = repository.findByLogin(login).orElse(null);
            if (user != null) {
                user.setPassword(passwordEncoder.encode(password));
                user = repository.save(user);
            }
        } // Other error!!
        catch (Exception e) {
            error = e.getLocalizedMessage();
        } // Other error!!
        return error;
    }

}
