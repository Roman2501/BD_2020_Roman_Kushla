/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.service;

import com.movie.entity.Client;
import com.movie.entity.Operator;
import com.movie.entity.Rent;
import com.movie.entity.Roles;
import com.movie.form.ClientForm;
import com.movie.repos.ClientRepository;
import com.movie.repos.RentRepository;
import com.movie.repos.RolesRepository;
import com.movie.repos.UsersRepository;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Root
 */
@Service
public class ClientService {
     private static final Logger logger = LoggerFactory.getLogger(ClientService.class);

    @Autowired
    private UsersRepository userRepository;
    
    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private RolesRepository roleRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;
    
     @Autowired 
    RentRepository rentRepository;
     
    int size =25;
    
     @Transactional
    public String updateClient(String login, String lastName, String firstName, String phone,  String document,String note) {
        String error = null;
        Client newUser = null;
        try {
            newUser = clientRepository.findClientByLogin(login);
            if (newUser != null) {
                newUser.setLastName(lastName);
                newUser.setFirstName(firstName);
                newUser.setPhone(phone);
                newUser.setNote(note);
                newUser.setDocument(document);
                newUser = clientRepository.save(newUser);
            }
        } catch (Exception e) {
            error = e.getLocalizedMessage();
            logger.error(e.getMessage());
            
        }
        return error;
    }

    public String createClient(ClientForm form) {
        String error = null;
        Client newUser = null;
        try {
            newUser = new Client();
            newUser.setLogin(form.getLogin().toLowerCase());
            newUser.setFirstName(form.getFirstName());
            newUser.setLastName(form.getLastName());
            newUser.setPhone(form.getPhone());
            newUser.setDocument(form.getDocument());
            newUser.setNote(form.getNote());
            newUser.setEnabled(true);
            newUser.setPassword(passwordEncoder.encode(form.getPassword()));
            Roles role = roleRepository.findByRoleName(form.getRole());
            newUser.setRole(role);
            newUser = clientRepository.save(newUser);
        } // Other error!!
        catch (Exception e) {
            error = e.getLocalizedMessage();
             logger.error(e.getMessage());
        }
        return error;
    }
    
     public List<Client> getClients(int page, int size, String sort) {
        if (sort==null || sort.isEmpty()) sort="login";
        Pageable pageable = PageRequest.of(page, size, Sort.by(sort).ascending());
        return clientRepository.findAllClients(pageable);
    }
    
    public Client getClient(String login) {
        return clientRepository.findClientByLogin(login);
    }
    public List<Client> find(int page, String login) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("lastName").ascending());
        return clientRepository.findClient(pageable,login);
    }
    
    public List<Rent> getActiveRentByClint(String login){
        Client client =  clientRepository.findById(login).orElse(null);
        return rentRepository.findActiveRentByClient(client);
    }
    
    public List<Rent> getAllRentByClient(int page,int size, String login){
        Client client =  clientRepository.findById(login).orElse(null);
        Pageable pageable = PageRequest.of(page, size, Sort.by("issueDate").ascending());
        return rentRepository.findRentByClient(pageable,client);
    }
     public Optional<Rent> getRentByID(long id){
         
        return rentRepository.findById(id);
    }
}
