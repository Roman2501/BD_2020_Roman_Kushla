/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.service;

import com.movie.entity.Actor;
import com.movie.entity.Category;
import com.movie.entity.Country;
import com.movie.entity.Film;
import com.movie.entity.Ganre;
import com.movie.entity.Producer;
import com.movie.form.FilmForm;
import com.movie.repos.ActorRepository;
import com.movie.repos.CategoryRepository;
import com.movie.repos.CountryRepository;
import com.movie.repos.FilmRepository;
import com.movie.repos.GanreRepository;
import com.movie.repos.ProducerRepository;
import java.util.Date;
import java.util.List;
import java.util.Set;
import org.hibernate.boot.archive.scan.spi.ClassDescriptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Root
 */
@Service
public class FilmService {
     private static final Logger logger = LoggerFactory.getLogger(FilmService.class);
     int size = 25;
     @Autowired FilmRepository filmRepos;
     @Autowired ProducerRepository prodRepository;
     @Autowired ActorRepository actorRepository;
     @Autowired CountryRepository countryRepository;
     @Autowired CategoryRepository categoryRepository;
     @Autowired GanreRepository ganreRepository;
     
     public List<Film> getAviable(int page){
         Pageable pageable = PageRequest.of(page, size, Sort.by("name").ascending());
         return  filmRepos.findAllFilm(pageable);
     }
     
     public List<Film> getAviableByName(int page,String name){
         Pageable pageable = PageRequest.of(page, size, Sort.by("name").ascending());
         return  filmRepos.findAllByName(pageable, name);
     }
     
     @Transactional
     public Film save(FilmForm form){
         Film film = null;
         if (form.getId()>0){
             film = filmRepos.findById(form.getId()).orElse(null);
             if (film==null) film = new Film();
         }
         film.setName(form.getName());
         film.setAddDate(new Date());
         film.setYear(form.getYear());
         film.setAviable(form.getAviable());
         film.setPoster(form.getPath());
         film.setNote(form.getNote());
         Category category= categoryRepository.findByCode(form.getCategory()).orElse(null);
         film.setCategory(category);
         Country country = countryRepository.findByCode(form.getCountry()).orElse(null);
         film.setCountry(country);
         Ganre  ganre = ganreRepository.findByName(form.getGanre()).orElse(null);
         film.setGanre(ganre);
         Producer producer = prodRepository.findById(form.getProducer()).orElse(null);
         film.setProducer(producer);
         Set<Long> actors =  form.getActors();
         for(Long a:actors){
                  Actor actor = actorRepository.findById(a).orElse(null);
                  if (actor!=null) film.getActors().add(actor);
         }
         Film filmSave = null;
         filmSave =filmRepos.save(film);
         return filmSave;
         
         
     }
     
     
    
}
