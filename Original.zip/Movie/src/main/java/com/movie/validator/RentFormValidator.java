/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.validator;

import com.movie.form.RentForm;
import java.util.Date;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

/**
 *
 * @author Root
 */
@Component
public class RentFormValidator implements Validator {

    @Override
    public boolean supports(Class<?> type) {
        return type == RentForm.class;
    }

    @Override
    public void validate(Object o, Errors errors) {
        RentForm form = (RentForm) o;

        if (form.getIssueDate() == null) {
            errors.rejectValue("beginDate", "NotEmpty.date.beginDate");
        }
        if (form.getCloseDate() == null) {
            errors.rejectValue("endDate", "NotEmpty.date.endDate");
        }
        if (form.getIssueDate() != null && form.getCloseDate() != null) {
            if (form.getIssueDate().getTime() > form.getCloseDate().getTime()) {
                errors.rejectValue("beginDate", "Math.date.date");
            }
        }

    }

}
