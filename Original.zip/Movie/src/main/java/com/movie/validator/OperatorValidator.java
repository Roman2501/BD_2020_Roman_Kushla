/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.validator;

import com.movie.entity.Users;
import com.movie.form.OperatorForm;
import com.movie.repos.UsersRepository;
import com.movie.util.ValidationConts;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/**
 *
 * @author Root
 */

@Component
public class OperatorValidator implements Validator {

    @Autowired
    UsersRepository repository;
    //private final String PASSWORD_PATTERN = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})";
    //private final String EMAIL_PATTERN = "^[a-zA-Z0-9_!#$%&’*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$";
    //private final String USERNAME_PATTERN = "^[a-z0-9_@]{3,25}$";
    Pattern pattern;
    Matcher matcher;

    // The classes are supported by this validator.
    @Override
    public boolean supports(Class<?> clazz) {
        return clazz == OperatorForm.class;
    }

    @Override
    public void validate(Object target, Errors errors) {
        OperatorForm userForm = (OperatorForm) target;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName", "NotEmpty.userForm.firstName");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName", "NotEmpty.userForm.lastName");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "login", "NotEmpty.userForm.login");

        if (!userForm.isOld()) {
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "NotEmpty.userForm.password");
            ValidationUtils.rejectIfEmptyOrWhitespace(errors, "confirmPassword", "NotEmpty.userForm.confirmPassword");
            if (!userForm.getLogin().isEmpty()) {
                Users users = repository.findByLogin(userForm.getLogin().toLowerCase()).orElse(null);
                if (users != null) {
                    // Email has been used by another account.
                    errors.rejectValue("login", "Duplicate.userForm.login");
                }

                if (!validate(ValidationConts.LOGIN, userForm.getLogin().toLowerCase())) {
                    errors.rejectValue("login", "Match.userForm.email");
                }
            }
            if (!userForm.getPassword().isEmpty() && !validate(ValidationConts.LIGHT_PASSWORD, userForm.getPassword())) {
                errors.rejectValue("confirmPassword", "Match.userForm.password");
            }
        }

    }

    private boolean validate(String pat, String str) {
        pattern = Pattern.compile(pat);
        matcher = pattern.matcher(str);
        return matcher.matches();
    }
}

