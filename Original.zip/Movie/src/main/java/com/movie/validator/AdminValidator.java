/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.validator;

import com.movie.entity.Users;
import com.movie.form.AdminForm;
import com.movie.repos.UsersRepository;
import com.movie.util.ValidationConts;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
/**
 *
 * @author Root
 */
@Component
public class AdminValidator implements Validator {

    @Autowired
    UsersRepository repository;
  
    Pattern pattern;
    Matcher matcher;

    // The classes are supported by this validator.
    @Override
    public boolean supports(Class<?> clazz) {
        return clazz == AdminForm.class;
    }

    @Override
    public void validate(Object target, Errors errors) {
        AdminForm userForm = (AdminForm) target;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName", "NotEmpty.userForm.firstName");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName", "NotEmpty.userForm.lastName");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "login", "NotEmpty.userForm.login");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "NotEmpty.userForm.password");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "role", "NotEmpty.userForm.role");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "confirmPassword", "NotEmpty.userForm.confirmPassword");

        if (!userForm.getLogin().isEmpty()) {
            Users users = repository.findByLogin(userForm.getLogin().toLowerCase()).orElse(null);
            if (users != null) {
                // Email has been used by another account.
                errors.rejectValue("login", "Duplicate.userForm.login");
            }

            if (!validate(ValidationConts.LOGIN, userForm.getLogin().toLowerCase())) {
                errors.rejectValue("login", "Match.userForm.login");
            }
        }
        if (!errors.hasErrors()) {
            if (!userForm.getConfirmPassword().equals(userForm.getPassword())) {
                errors.rejectValue("confirmPassword", "Match.userForm.confirmPassword");
            }
        }
        if (!userForm.getPassword().isEmpty() && !validate(ValidationConts.STRONG_PASSWORD, userForm.getPassword())) {
            errors.rejectValue("confirmPassword", "Match.userForm.password");
        }

    }

    private boolean validate(String pat, String str) {
        pattern = Pattern.compile(pat);
        matcher = pattern.matcher(str);
        return matcher.matches();
    }

}

