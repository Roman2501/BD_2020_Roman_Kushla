/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.repos;

import com.movie.entity.Client;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Root
 */
@Repository
public interface ClientRepository  extends JpaRepository<Client, Object>{
    @Query("SELECT c FROM Client c  WHERE c.login =  ?1")
    Client findClientByLogin(String login);
    
    @Query("SELECT c FROM Client c  WHERE c.login like  :login or c.lastName like :login or c.firstName like :login")
    List<Client> findClientByLike(String login);
    
    @Query("SELECT c FROM Client c ")
    List<Client> findAllClients(Pageable pageable );
    
    @Query("SELECT u FROM Client u WHERE u.login like  ?1 or u.lastName like ?1")
    List<Client> findClient(Pageable pageable,String login);

    
    @Query("select count(b.login) from Client b")
    long getCount();

}
