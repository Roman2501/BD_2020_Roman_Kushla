/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.repos;

import com.movie.entity.Actor;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Root
 */
@Repository
public interface ActorRepository  extends JpaRepository<Actor, Long>{
    @Query("SELECT a FROM Actor a WHERE a.firstName = ?1 and a.lastName =?2")
    Optional<Actor> findByFirtNameAndLastName(String firstName,String lastName);
}
