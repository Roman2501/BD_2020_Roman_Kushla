/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.repos;

import com.movie.entity.Users;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Root
 */
@Repository
public interface UsersRepository extends JpaRepository<Users, String>{
    
    @Query("SELECT u FROM Users u WHERE u.login = ?1")
    Optional<Users> findByLogin(String login);
    
    @Query("SELECT u FROM Users u WHERE u.login = ?1 and u.isEnabled=true")
    Optional<Users> findActiveByLogin(String login);
    
    @Query("SELECT u FROM Users u WHERE u.login like  ?1 or u.lastName like ?1")
    List<Users> findUser(String login);

}
