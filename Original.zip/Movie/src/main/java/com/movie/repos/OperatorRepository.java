/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.repos;

import com.movie.entity.Operator;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Root
 */
@Repository
public interface OperatorRepository  extends JpaRepository<Operator, Object>{
    @Query("select e from Operator e ")
    List<Operator> findAllOpers(Pageable pageable);
    
    @Query("select e from Operator e  where e.login like ?1")
    Operator findByLogin(String login);
    
     @Query("select count(b.login) from Operator b")
     long getCount();
     
   
     
     @Query("select e from Operator e  where e.isEnabled=true and  e.login not in :logins")
     List<Operator> findByLogins(List<String> logins);
     
     @Query("select e from Operator e  where e.isEnabled=true ")
     List<Operator> findAllActive();

}
