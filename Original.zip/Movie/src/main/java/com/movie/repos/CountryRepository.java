/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.repos;

import com.movie.entity.Country;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Root
 */
@Repository
public interface CountryRepository  extends JpaRepository<Country, String>{
    @Query("SELECT u FROM Country u WHERE u.name = ?1")
    Optional<Country> findByName(String name);
    @Query("SELECT u FROM Country u WHERE u.code = ?1")
    Optional<Country> findByCode(String code);
}
