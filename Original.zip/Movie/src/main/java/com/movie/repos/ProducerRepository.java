/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.repos;

import com.movie.entity.Producer;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Root
 */
@Repository
public interface  ProducerRepository extends JpaRepository<Producer, Long>{
    @Query("SELECT p FROM Producer p WHERE p.firstName = ?1 and p.lastName =?2")
    Optional<Producer> findByFirtNameAndLastName(String firstName,String lastName);
}
