/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.repos;

import com.movie.entity.Roles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Root
 */
@Repository
public interface RolesRepository  extends JpaRepository<Roles, String>{
     @Query("SELECT r FROM Roles r WHERE r.roleName = ?1")
      public Roles findByRoleName(String role);

}
