/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.repos;

import com.movie.entity.Cart;
import com.movie.entity.Film;
import com.movie.entity.Operator;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Root
 */
@Repository
public interface CartRepository extends JpaRepository<Cart, String>{
    //@Query("delete  from Cart c where c.film =?1 and  c.oper=?2")
    int deleteByFilmAndOper(Film film,Operator operator);
    
    @Query("select c.film from Cart c where c.oper=?1")
    List<Film> findByOperator(Operator operator);
    
    int  deleteByOper(Operator operator);
}
