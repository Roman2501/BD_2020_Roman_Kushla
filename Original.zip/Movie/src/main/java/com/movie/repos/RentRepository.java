/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.repos;

import com.movie.entity.*;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Root
 */

@Repository
public interface RentRepository extends JpaRepository<Rent, Long>{
    @Query("Select r from Rent r where r.operator = ?1 and r.returnDate is null")
    List<Rent> findActiveRentByOper(Operator oper);
    @Query("Select r from Rent r where r.operator = ?1 and r.returnDate is not null")
    List<Rent> findRentByOper(Pageable page, Operator oper);
     @Query("Select r from Rent r where r.client = ?1 and r.returnDate is not null")
    List<Rent> findRentByClient(Pageable page, Client client);
     @Query("Select r from Rent r where r.client = ?1 and r.returnDate is null")
    List<Rent> findActiveRentByClient(Client client);
}
