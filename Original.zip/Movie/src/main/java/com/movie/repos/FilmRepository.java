/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.repos;

import com.movie.entity.Country;
import com.movie.entity.Film;
import com.movie.entity.Ganre;
import com.movie.entity.Producer;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Root
 */
@Repository
public interface FilmRepository extends JpaRepository<Film, Long>{
   
    @Query("SELECT p FROM Film p WHERE p.name = ?1 and p.producer =?2")
    Optional<Film> findByNameAndProducer(String name,Producer producer); 
    
    @Query("SELECT p FROM Film p WHERE p.id = ?1")
    Optional<Film> findById(long id); 
    
    @Query("SELECT f FROM Film f where f.aviable>0")
    List<Film> findAllFilm(Pageable pageable );
    
    @Query("SELECT f FROM Film f where f.aviable>0 and f.ganre=?1 ")
    List<Film> findAllByGanre(Pageable pageable,Ganre ganre );
    
    @Query("SELECT f FROM Film f where f.aviable>0 and f.country=?1 ")
    List<Film> findAllByCountry(Pageable pageable,Country country );
    
    @Query("SELECT f FROM Film f where f.aviable>0 and f.name like ?1 ")
    List<Film> findAllByName(Pageable pageable, String name );
    
    @Query("SELECT f FROM Film f where f.aviable>0 and f.producer = ?1 ")
    List<Film> findAllByProducer(Pageable pageable, Producer producer );
    
    @Modifying
    @Query("update Film f set f.aviable=f.aviable+1 where f.id=?1")
    int updateById(long id);
    
    
    
    
}
