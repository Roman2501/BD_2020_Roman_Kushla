/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.util;

/**
 *
 * @author Root
 */
public class ValidationConts {
  public static  final String LOGIN = "^[a-z0-9_-]{6,25}$";
  public static final String STRONG_PASSWORD = "((?=.*[a-z])(?=.*\\d)(?=.*[A-Z])(?=.*[@#$%!]).{8,40})";
  public static final String LIGHT_PASSWORD = "^[a-z0-9_-]{6,18}$";
  public static final String EMAIL = "^[a-z0-9_.@]{2,25}$";
}
