/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.util;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

/**
 *
 * @author Root
 */
@Component
public class CartConfig {

    @Bean(name = "cartSize")
    @SessionScope
    public CartSize sessionScopedBean() {
        return new CartSize();
    }
}
