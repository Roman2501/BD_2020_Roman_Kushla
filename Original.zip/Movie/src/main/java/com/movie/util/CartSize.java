/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.util;

import com.movie.entity.Film;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Getter
@Setter
public class CartSize  {
    
    List<Film> films = new ArrayList<>();

    public CartSize() {
    }
    public int getSize(){
        return  films.size();
    }
    
    
}
