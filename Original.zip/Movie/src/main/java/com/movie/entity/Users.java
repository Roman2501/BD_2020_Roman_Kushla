/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Entity
@Table(name = "users")

@Inheritance(
    strategy = InheritanceType.JOINED
)

@Getter
@Setter
public class Users implements Serializable{

    @Id
    @Column(name = "user_login",nullable = false,length = 100)
    private String login;
    @Column(name = "user_password",nullable = false,length = 128)
    private String password;

    @Column(name = "first_name",nullable = true,length = 100)
    private String firstName;
    @Column(name = "last_name",nullable = false,length = 100)
    private String lastName;
    
    
    @Column(name = "is_enabled")
    private boolean isEnabled = true;
    
    @ManyToOne
    @JoinColumn(name = "role_name",nullable = false)
    private Roles role;


    public Users() {
        this.isEnabled = true;
    }
    
    

    

    
    
}
