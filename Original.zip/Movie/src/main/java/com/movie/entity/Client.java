/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Entity 
@Table(name = "clients")
@Getter
@Setter
public class Client extends Users{
    

     @Column(name = "phone",length = 200)
     String phone;
     
     @Column(name = "document",length = 1000)
     String document;
     
     @Column(name = "note",length = 1000)
     String note;
     
     @ManyToMany(fetch = FetchType.LAZY,mappedBy = "client")
     @JsonIgnore
     List<Rent> rents  = new ArrayList<>();

    @Override
    public String toString() {
        return getLastName()+" "+getFirstName();
    }
     
    
      
         
  
     
  
    
   
     
    
}

