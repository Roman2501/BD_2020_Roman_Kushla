/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Entity
@Table(name = "films")
@Getter
@Setter
public class Film implements Serializable{
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)   
    public long id;
    
    @Column(name="name")
    String name;
    @Column(name = "film_year")
    int year;
    
   
    @Column(name = "film_aviable",columnDefinition ="number(2,0) CHECK (film_aviable>=0)")
    int aviable = 1;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "country_code", referencedColumnName = "code")
    Country country;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "producer_id", referencedColumnName = "id")
    Producer producer;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ganre", referencedColumnName = "name")
    Ganre ganre;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
      name = "film_actor", indexes = {@Index(name = "film_idx", columnList="film_id", unique = false)},
        joinColumns = @JoinColumn(name = "film_id"), 
        inverseJoinColumns = @JoinColumn(name = "actor_id")
        )
    Set<Actor> actors  = new HashSet<>();
    
    @Column(name = "note",length = 4000)
    String note;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "category", referencedColumnName = "code")
    Category category;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "add_date")
    Date addDate;
    
    
    @ManyToMany(fetch = FetchType.LAZY,mappedBy = "film")
    @JsonIgnore
    List<Rent> rents = new ArrayList<>();
    @Column(name = "poster")
    String poster;
    
    @OneToMany(mappedBy = "film",fetch = FetchType.LAZY)
    @JsonIgnore
    private List<Cart> cart;
    
    
    public Film(){
        
    }
    
    
    
    
    
    
    
}
