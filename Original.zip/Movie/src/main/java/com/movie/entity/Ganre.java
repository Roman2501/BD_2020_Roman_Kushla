/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.ArrayList;

import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;

/**
 *
 * @author Root
 */
@Entity
@Table(name = "ganres")
@Data
public class Ganre implements Serializable{
    @Id
    @Column(name="name",length = 100)        
    String name;
    
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "ganre")
    @JsonIgnore
    List<Film> films = new ArrayList<>();

    public Ganre(String name) {
        this.name = name;
    }

    public Ganre() {
    }
    
     
   
}
