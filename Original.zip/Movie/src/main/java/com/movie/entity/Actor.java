/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import lombok.Data;


/**
 *
 * @author Root
 */
@Entity
@Table(name="actors")
@Data
public class Actor implements Serializable{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)     
    long id;
    @Column(name = "first_name",length = 100)
    String firstName;
    
    @Column(name = "last_name",length = 100)
    String lastName;
    
    @ManyToMany(fetch = FetchType.LAZY,mappedBy = "actors")
    @JsonIgnore
    List<Film> films = new ArrayList<>();

    public Actor(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public Actor() {
    }
    
    
    
   
}
