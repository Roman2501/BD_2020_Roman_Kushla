/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import lombok.Data;

/**
 *
 * @author Root
 */
@Entity
@Table(name = "rents",
        indexes = {@Index(name = "rent_idx2", columnList="issue_date DESC", unique = false),
        @Index(name = "rent_idx3", columnList="return_date DESC", unique = false)})
@Data
public class Rent {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)    
    long id;
    
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
      name = "rent_film", 
         indexes = {@Index(name = "rent_idx", columnList="film_id", unique = false)},    
        joinColumns = @JoinColumn(name = "rent_id"), 
        inverseJoinColumns = @JoinColumn(name = "film_id"))
    List<Film> film = new ArrayList<>();
    
    @OneToMany(fetch = FetchType.EAGER,mappedBy = "rent")
    @JsonIgnore
    Set<Cash> cash  = new HashSet<>();

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "client", referencedColumnName = "user_login")                     
    Client client;
 
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "operator", referencedColumnName = "user_login")            
    Operator operator;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="issue_date")        
    Date issueDate;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="return_date")      
    Date returnDate;
    
    float cost;
    
    @Column(name="balance")
    float balance;
    
    @Column(name="deposite")
    float deposite;
    
    int days;
    
    
    
    
    
    
    
}
