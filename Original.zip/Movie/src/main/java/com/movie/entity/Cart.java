/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.entity;

import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Entity
@Table(name="cart",indexes = {@Index(name = "cart_uq_idx",  columnList="film_id,operator", unique = true)})
@Getter
@Setter
public class Cart implements Serializable{
    @Id
    String id;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "FILM_ID", referencedColumnName = "ID")
    public Film film;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "OPERATOR", referencedColumnName = "user_login")
    public Operator oper;

    public Cart() {
        this.id = UUID.randomUUID().toString();
    }
    
    
    
}
