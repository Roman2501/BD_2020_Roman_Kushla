/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;

/**
 *
 * @author Root
 */
@Entity
@Table(name="categories")
@Data
public class Category {
    @Id
    @Column(length = 10)
    String code;
    @Column(length = 100)
    String name;
    
    @Column
    float cost;
    
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "category")
    @JsonIgnore
    List<Film> films  = new ArrayList<>();;

    public Category(String code, String name,float cost) {
        this.code = code;
        this.name = name;
        this.cost = cost;
    }

    public Category() {
    }
    

}
