/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Entity
@Table(name="producers")
@Getter
@Setter
public class Producer implements Serializable{
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)     
    public long id;
    @Column(name = "first_name",length = 100)
    public String firstName;
    
    @Column(name = "last_name",length = 100)
    public String lastName;
    
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "producer")
    @JsonIgnore        
    List<Film> films = new ArrayList<>();

    public Producer(String firstName, String lastName) {
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public Producer() {
    }
    
    
    
}
