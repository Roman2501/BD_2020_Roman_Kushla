/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Root
 */
@Entity
@Table(name = "operators")
@Getter
@Setter
public class Operator extends Users{
  
    
     @Column(name = "phone",length = 200)
     String phone;
     
     @Column(name = "note",length = 1000)
     String note;
     
     @OneToMany(fetch = FetchType.LAZY,mappedBy = "operator")
     @JsonIgnore
     List<Cash> cash = new ArrayList<>();
     
     @OneToMany(fetch = FetchType.LAZY,mappedBy = "operator")
     @JsonIgnore
     List<Rent> rents = new ArrayList<>();
     
     @OneToMany(mappedBy = "oper",fetch = FetchType.LAZY)
     @JsonIgnore
     private List<Cart> cart;
     

    
}
