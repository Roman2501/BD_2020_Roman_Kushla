/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.Data;

/**
 *
 * @author Root
 */
@Entity
@Table(name="countries")
@Data
public class Country {
    @Id
    @Column(name = "code",length = 5)
    String code;
    @Column(name = "name",length = 100)
    String name;
    
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "country")
    @JsonIgnore
    List<Film> film  = new ArrayList<>();

    public Country(String code, String name) {
        this.code = code;
        this.name = name;
    }

    public Country() {
    }
    
    
}
