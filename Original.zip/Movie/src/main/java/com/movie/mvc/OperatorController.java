/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.mvc;


import com.movie.entity.Cash;
import com.movie.entity.Client;
import com.movie.entity.Film;
import com.movie.entity.Rent;
import com.movie.entity.Roles;
import com.movie.entity.Users;
import com.movie.form.ClientForm;
import com.movie.form.PasswordForm;
import com.movie.form.RentForm;
import com.movie.service.CartService;
import com.movie.service.ClientService;
import com.movie.service.FilmService;
import com.movie.service.OperatorService;
import com.movie.service.RoleService;
import com.movie.service.UserService;
import com.movie.util.CartSize;
import com.movie.util.Messages;
import com.movie.validator.RentFormValidator;
import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 *
 * @author Root
 */
@Controller
public class OperatorController {
    int onPage = 25;
    String searchStr;
    @Autowired
    CartService cartService;
    @Autowired
    FilmService filmService;
    @Autowired
    OperatorService operService;
    @Autowired
    ClientService clientService;
    
    @Autowired CartSize carsSize;
    
     @Autowired
    RoleService roleService;
     
      @Autowired
    UserService userService;
    
    

    @Autowired
    private HttpServletRequest request;
    @Autowired
    ServletContext context;
    @Autowired
    Messages msg;

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    @Autowired  RentFormValidator rentValidator;
    
    Client clientChoise;

  

    private static final Logger logger = LoggerFactory.getLogger(OperatorController.class);

    @InitBinder
    protected void initBinder(WebDataBinder dataBinder) {

        Object target = dataBinder.getTarget();
        if (target == null) {
            return;
        }
        
        if (target.getClass() == RentForm.class) {
            dataBinder.setValidator(rentValidator);
        }
        dateFormat.setLenient(false);
        dataBinder.registerCustomEditor(Date.class, null, new CustomDateEditor(dateFormat, true));
    }

    @RequestMapping("/work")
    public String welocome(Model model,Principal principal,
             @RequestParam(name = "page", required = false, defaultValue = "1") int page) {
        cartService.getCart(principal.getName());
        if (page<=0){page=1;}
        int prev = page;
        if (prev > 1) {
            prev--;
            model.addAttribute("prev", prev);
        }
        List<Film> films = filmService.getAviable(page-1);
        int next = page;
        next++;
        model.addAttribute("next", next);
        model.addAttribute("films", films);
        model.addAttribute("page", page);
        return "work/index";
    }
    
    @RequestMapping("/work/order/new")
    public String newOrder(Model model,Principal principal,
        @RequestParam(name = "page", required = false, defaultValue = "1") int page) {
        if (page <= 0) {
            page = 1;
        }
        int prev = page;
        if (prev > 1) {
            prev--;
            model.addAttribute("prev", prev);
        }
        int next = page;
        next++;
        List<Film> films = filmService.getAviable(page-1);
        model.addAttribute("next", next);
        model.addAttribute("films", films);
        model.addAttribute("page", page);
        return "/work/order";
    }
    
    @RequestMapping(value = "/work/find", method = {RequestMethod.GET, RequestMethod.POST})
    public String findUser(@RequestParam(name = "search", required = false, defaultValue = "") String search, 
            Model model, @RequestParam(name = "page", required = false, defaultValue = "1") int page,
            HttpServletRequest request) {
        if (search.isEmpty() && searchStr == null) {
            String referer = request.getHeader("Referer");
            return "redirect:" + referer;
        } else if (!search.isEmpty()) {
            searchStr = search;
        }
        if (page <= 0) {
            page = 1;
        }
        int prev = page;
        if (prev > 1) {
            prev--;
            model.addAttribute("prev", prev);
        }
        int next = page;
        next++;
        model.addAttribute("next", next);
        model.addAttribute("page", page);
        model.addAttribute("action","find");
        List<Client> list = clientService.find(page-1,search+"%");
        model.addAttribute("clients", list);
        return "work/clients";
    }
    @RequestMapping(value = "/work/clients", method = {RequestMethod.GET, RequestMethod.POST})
    public String getClients(
            Model model, @RequestParam(name = "page", required = false, defaultValue = "1") int page,
            HttpServletRequest request) {
        if (page <= 0) {
            page = 1;
        }
        int prev = page;
        if (prev > 1) {
            prev--;
            model.addAttribute("prev", prev);
        }
        int next = page;
        next++;
        model.addAttribute("next", next);
        model.addAttribute("page", page);
        model.addAttribute("action","clients");
        List<Client> list = clientService.getClients(page-1, onPage,"lastName");
        model.addAttribute("clients", list);
        return "work/clients";
    }
    
    @RequestMapping(value = "/work/films", method = {RequestMethod.GET, RequestMethod.POST})
    public String getFilms(
            Model model, @RequestParam(name = "page", required = false, defaultValue = "1") int page,
            HttpServletRequest request) {
        if (page <= 0) {
            page = 1;
        }
        int prev = page;
        if (prev > 1) {
            prev--;
            model.addAttribute("prev", prev);
        }
        int next = page;
        next++;
        model.addAttribute("next", next);
        model.addAttribute("page", page);
        List<Film> list = filmService.getAviable(page-1);
        model.addAttribute("films", list);
        return "work/films";
    }
    
    
    @RequestMapping(value = "/work/cart", method = {RequestMethod.GET, RequestMethod.POST})
    public String choseCart(Model model, Principal principal)
    {
        List<Film> films = cartService.getCart(principal.getName());
        model.addAttribute("films", films);
        model.addAttribute("client", clientChoise);
        float sum =  (float) films.stream().mapToDouble(f->f.getCategory().getCost()).sum();
        model.addAttribute("sum", sum);
        return "work/cart";
    }
    
    @RequestMapping(value = "/work/choseClient", method = { RequestMethod.POST})
    public String choseClient(Model model, Principal principal,
    @RequestParam("clientLogin") String login)
    {
        clientChoise = clientService.getClient(login);
        return "redirect:/work/cart";
    }
    
    @RequestMapping(value = "/work/confirm", method = { RequestMethod.POST})
    public String confirmOrder(Model model, Principal principal,
    @RequestParam("days") int days,
    @RequestParam("summa") float deposite
    )
    {
        Cash cash;
        try{
         cash = cartService.addToRent(principal.getName(),clientChoise, days,deposite);}
        catch(Exception ex){
          logger.error(ex.getMessage());
          return "redirect:/work/cart";
       }
         
         model.addAttribute("cash", cash);
         return "work/cash";
    }
    
    @RequestMapping(value = "/work/rent/{id}", method = { RequestMethod.GET})
    public String getRentById(Model model, Principal principal,@PathVariable long id)
    {
         Rent rents =  operService.getRentByID(id).orElse(null);
         if (rents!=null && rents.getReturnDate()==null){
             RentForm form = new RentForm(rents);
             model.addAttribute("rentForm", form);
         }
         model.addAttribute("rent", rents);
         return "work/rent";
    }
    
    @RequestMapping(value = "/work/rent", method = { RequestMethod.POST})
    public String saveRent(Model model, Principal principal,@ModelAttribute("rentForm") RentForm rentForm)
    {
        System.out.println(rentForm.getId());
        Cash cash;
        try {
            //(long id, Date closeDate,int days, float money,String login)
            cash = cartService.closeRent(
                    rentForm.getId(),
                    rentForm.getDays(),
                    rentForm.getMoney(),
                    principal.getName());
                    model.addAttribute("cash", cash);
         return "work/cash";
        } catch (Exception ex) {
            logger.error(ex.toString());
            System.out.println(ex.toString());
        }
        Rent rents =  operService.getRentByID(rentForm.getId()).orElse(null);
        rentForm = new RentForm(rents);
        model.addAttribute("rentForm", rentForm);
        
        return "redirect:/work/rent/"+rentForm.getId();
    }
    
    @RequestMapping(value = "/work/rents", method = { RequestMethod.GET})
    public String getActiveRents(Model model, Principal principal)
    {
         List<Rent> rents =  operService.getActiveRentByOper(principal.getName());
         model.addAttribute("rents", rents);
         return "work/rents";
    }
    
    
    @RequestMapping(value = "/work/rents/all", method = { RequestMethod.GET})
    public String getAllRents(Model model, Principal principal, @RequestParam(name = "page", required = false, defaultValue = "1") int page)
    {
         if (page <= 0) {
            page = 1;
        }
         int prev = page;
         if (prev > 1) {
             prev--;
            model.addAttribute("prev", prev);
         }
         int next = page;
         next++;
         model.addAttribute("next", next);
         model.addAttribute("page", page);
         model.addAttribute("action", "rents/all");
         List<Rent> rents =  operService.getAllRentByOper(page-1,onPage,principal.getName());
         model.addAttribute("rents", rents);
         return "work/rents";
    }
    
   
    
    
    
     @RequestMapping(value = "/work/resetPassword", method = RequestMethod.GET)
    public String ressetPassword(Model model, @RequestParam(name = "login", required = false, defaultValue = "") String login, Principal principal) {
        if (login.isEmpty()) {
            login = principal.getName();
        }
        if (principal.getName().equals(login)) {
            PasswordForm form = new PasswordForm(login);
            model.addAttribute("passForm", form);
            return "work/resetPassword";
        }
        return "work";

    }

    @RequestMapping(value = "/work/resetPassword", method = RequestMethod.POST)
    public String ressetingPassword(Model model, //
            @ModelAttribute("passForm") @Validated PasswordForm passForm, //
            BindingResult result,   final RedirectAttributes redirectAttributes) {
        // Validate result
        if (result.hasErrors()) {
            return "work/resetPassword";
        }
        String error = operService.resetPassword(passForm.getLogin(), passForm.getPassword());
        if (error != null && !error.isEmpty()) {
            model.addAttribute("errorMessage", "Error: " + error);
            return "work/resetPassword";
        }
        return "redirect:/work";
    }

@RequestMapping(value = "/work/client/{login}", method = RequestMethod.GET)
    public String getClient(@PathVariable String login, Model model, Principal principal) {
        Client client = null;
        if (login!=null && !login.isEmpty()){
           client = clientService.getClient(login);
        ClientForm form = new ClientForm();
        if (client != null) {
            form.setFirstName(client.getFirstName());
            form.setLastName(client.getLastName());
            form.setLogin(client.getLogin());
            form.setPhone(client.getPhone());
            form.setDocument(client.getDocument());
            form.setNote(client.getNote());
            form.setOld(true);
        model.addAttribute("clientForm", form);
        }
        }
        return "work/client";
    }
    
    @RequestMapping(value = "/work/client", method = RequestMethod.POST)
    public String updateClient(Model model, Principal principal,
            @ModelAttribute("clientForm") @Validated ClientForm clientForm, //
            BindingResult result, //
            final RedirectAttributes redirectAttributes) {
         Client client  = clientService.getClient(clientForm.getLogin());
           
         if (result.hasErrors()) {
            model.addAttribute("client", client);
            return "work/client";
        }
        String error = clientService.updateClient(clientForm.getLogin(),
                    clientForm.getLastName(),clientForm.getFirstName(), clientForm.getPhone(),
                    clientForm.getDocument(), clientForm.getNote());
        client  = clientService.getClient(clientForm.getLogin());
       
        if (error != null && !error.isEmpty()) {
             model.addAttribute("errorMessage", error);
             model.addAttribute("client", client);
            return "work/client";
        }
        model.addAttribute("msg", "Saved!");
        return "/work/client";
    }

    
    
     @RequestMapping(value = "/work/register/client", method = RequestMethod.GET)
    public String newRegisterClient(Model model) {

        ClientForm form = new ClientForm();
        List<Roles> roles = roleService.getAllRoles().stream().filter(r -> r.getRoleName().equals("ROLE_USER")).collect(Collectors.toList());
        model.addAttribute("roles", roles);
        model.addAttribute("info", msg.get("register.client.new"));
        model.addAttribute("action","/work/register/client");

        model.addAttribute("userForm", form);
        return "work/registerPage";
    }
    
    @RequestMapping(value = "/work/register/client", method = RequestMethod.POST)
    public String saveRegisterClient(Model model, //
            @ModelAttribute("userForm") @Validated ClientForm userForm, //
            BindingResult result, //
            final RedirectAttributes redirectAttributes) {
        // Validate result
        if (result.hasErrors()) {
            List<Roles> roles = roleService.getAllRoles().stream().filter(r -> r.getRoleName().equals("ROLE_USER")).collect(Collectors.toList());
            model.addAttribute("roles", roles);
            model.addAttribute("info", msg.get("register.client.new"));
            model.addAttribute("action","/work/register/client");
            return "work/registerPage";
        }
        String error = clientService.createClient(userForm);
        if (error != null && !error.isEmpty()) {
            List<Roles> roles = roleService.getAllRoles().stream().filter(r -> r.getRoleName().equals("ROLE_USER")).collect(Collectors.toList());
            model.addAttribute("roles", roles);
            model.addAttribute("errorMessage", error);
            model.addAttribute("info", msg.get("register.client.new"));
             model.addAttribute("action","/work/register/client");
            return "work/registerPage";
        }
        Users user = userService.getUserByLogin(userForm.getLogin());
        redirectAttributes.addFlashAttribute("flashUser", user);

        return "redirect:/work/registerSuccessful";
    }
    
    
    
    
    


    
}
