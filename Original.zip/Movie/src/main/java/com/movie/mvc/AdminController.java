/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.mvc;

import com.movie.entity.Actor;
import com.movie.entity.Category;
import com.movie.entity.Client;
import com.movie.entity.Country;
import com.movie.entity.Film;
import com.movie.entity.Ganre;
import com.movie.entity.Operator;
import com.movie.entity.Producer;
import com.movie.entity.Roles;
import com.movie.entity.Users;
import com.movie.validator.ClientValidator;
import com.movie.validator.OperatorValidator;
import com.movie.validator.AdminValidator;
import com.movie.form.AdminForm;
import com.movie.form.ClientForm;
import com.movie.form.FilmForm;
import com.movie.form.OperatorForm;
import com.movie.form.PasswordForm;
import com.movie.repos.ActorRepository;
import com.movie.repos.CategoryRepository;
import com.movie.repos.CountryRepository;
import com.movie.repos.FilmRepository;
import com.movie.repos.GanreRepository;
import com.movie.repos.ProducerRepository;
import com.movie.service.AdminService;
import com.movie.service.ClientService;
import com.movie.service.FilmService;
import com.movie.service.OperatorService;
import com.movie.service.RoleService;
import com.movie.service.UserService;
import com.movie.util.Messages;
import com.movie.validator.PasswordValidator;
import java.io.File;
import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 *
 * @author Root
 */
@Controller
public class AdminController {

    int onPage = 25;
    String searchStr;
    @Autowired
    AdminService adminService;
    @Autowired
    UserService userService;
    @Autowired
    ClientService clientService;
    @Autowired
    OperatorService operService;
    @Autowired
    RoleService roleService;
    @Autowired
    private HttpServletRequest request;
    @Autowired
    ServletContext context;
    @Autowired
    Messages msg;
    @Autowired FilmRepository films;
    
     @Autowired
    FilmService filmService;

    @Autowired
    ProducerRepository producers;
    @Autowired
    ActorRepository actors;
    @Autowired
    CountryRepository countris;
    @Autowired 
    CategoryRepository categories;
    @Autowired 
    GanreRepository ganres;

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    @Autowired
    AdminValidator userValidator;
    @Autowired
    OperatorValidator operatorValidator;
    @Autowired
    ClientValidator clientValidator;
    @Autowired
    PasswordValidator passwordValidator;

    private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

    @InitBinder
    protected void initBinder(WebDataBinder dataBinder) {

        Object target = dataBinder.getTarget();
        if (target == null) {
            return;
        }
        if (target.getClass() == AdminForm.class) {
            dataBinder.setValidator(userValidator);
        }

        if (target.getClass() == OperatorForm.class) {
            dataBinder.setValidator(operatorValidator);
        }
        if (target.getClass() == ClientForm.class) {
            dataBinder.setValidator(clientValidator);
        }

        if (target.getClass() == PasswordForm.class) {
            dataBinder.setValidator(passwordValidator);
        }
        dateFormat.setLenient(false);
        dataBinder.registerCustomEditor(Date.class, null, new CustomDateEditor(dateFormat, true));
    }

    @RequestMapping("/admin")
    public String welocome(Model model) {
        return "/admin/index";
    }

    @RequestMapping("/admin/registerSuccessful")
    public String viewRegisterSuccessful(Model model) {
        return "/admin/registerSuccessfulPage";
    }

    @RequestMapping(value = "/admin/register", method = RequestMethod.GET)
    public String newRegisterAdmin(Model model) {

        AdminForm form = new AdminForm();
        Roles role = roleService.getRoleByName("ROLE_ADMIN");
        model.addAttribute("info", msg.get("register.admin.new"));
        model.addAttribute("roles", role);
        model.addAttribute("action", "/admin/register");
        model.addAttribute("userForm", form);
        return "admin/registerPage";
    }

    @RequestMapping(value = "/admin/register", method = RequestMethod.POST)
    public String saveRegisterAdmin(Model model, //
            @ModelAttribute("userForm") @Validated AdminForm userForm, //
            BindingResult result, //
            final RedirectAttributes redirectAttributes) {
        // Validate result
        if (result.hasErrors()) {
            List<Roles> roles = roleService.getAllRoles().stream().filter(r -> r.getRoleName().equals("ROLE_ADMIN")).collect(Collectors.toList());
            model.addAttribute("roles", roles);
            model.addAttribute("info", msg.get("register.admin.new"));
            model.addAttribute("action", "/admin/register");
            return "admin/registerPage";
        }
        String error = adminService.createUser(userForm.getLogin(), userForm.getFirstName(), userForm.getLastName(), userForm.getPassword(), userForm.getRole());
        if (error != null && !error.isEmpty()) {
            List<Roles> roles = roleService.getAllRoles().stream().filter(r -> r.getRoleName().equals("ROLE_ADMIN")).collect(Collectors.toList());
            model.addAttribute("roles", roles);
            model.addAttribute("info", msg.get("register.admin.new"));
            model.addAttribute("action", "/admin/register");
            model.addAttribute("errorMessage", error);
            return "admin/registerPage";
        }
        Users user = userService.getUserByLogin(userForm.getLogin());
        redirectAttributes.addFlashAttribute("flashUser", user);

        return "redirect:/admin/registerSuccessful";
    }

    @RequestMapping(value = "/admin/register/client", method = RequestMethod.GET)
    public String newRegisterClient(Model model) {

        ClientForm form = new ClientForm();
        List<Roles> roles = roleService.getAllRoles().stream().filter(r -> r.getRoleName().equals("ROLE_USER")).collect(Collectors.toList());
        //if (role!=null){
        //form.setRole(role.getName());
        //}
        model.addAttribute("roles", roles);
        model.addAttribute("info", msg.get("register.client.new"));
        model.addAttribute("action", "/admin/register/client");

        model.addAttribute("userForm", form);
        return "admin/registerPage";
    }

    @RequestMapping(value = "/admin/register/client", method = RequestMethod.POST)
    public String saveRegisterClient(Model model, //
            @ModelAttribute("userForm") @Validated ClientForm userForm, //
            BindingResult result, //
            final RedirectAttributes redirectAttributes) {
        // Validate result
        if (result.hasErrors()) {
            List<Roles> roles = roleService.getAllRoles().stream().filter(r -> r.getRoleName().equals("ROLE_USER")).collect(Collectors.toList());
            model.addAttribute("roles", roles);
            model.addAttribute("info", msg.get("register.client.new"));
            model.addAttribute("action", "/admin/register/client");
            return "admin/registerPage";
        }
        String error = clientService.createClient(userForm);
        if (error != null && !error.isEmpty()) {
            List<Roles> roles = roleService.getAllRoles().stream().filter(r -> r.getRoleName().equals("ROLE_USER")).collect(Collectors.toList());
            model.addAttribute("roles", roles);
            model.addAttribute("errorMessage", error);
            model.addAttribute("info", msg.get("register.client.new"));
            model.addAttribute("action", "/admin/register/client");
            return "admin/registerPage";
        }
        Users user = userService.getUserByLogin(userForm.getLogin());
        redirectAttributes.addFlashAttribute("flashUser", user);

        return "redirect:/admin/registerSuccessful";
    }

    @RequestMapping(value = "/admin/register/operator", method = RequestMethod.GET)
    public String newRegisterOperator(Model model) {

        OperatorForm form = new OperatorForm();
        List<Roles> roles = roleService.getAllRoles().stream().filter(r -> r.getRoleName().equals("ROLE_OPER")).collect(Collectors.toList());
        model.addAttribute("roles", roles);
        model.addAttribute("info", msg.get("register.oper.new"));
        model.addAttribute("action", "/admin/register/operator");
        model.addAttribute("userForm", form);
        return "admin/registerPage";
    }

    @RequestMapping(value = "/admin/register/operator", method = RequestMethod.POST)
    public String saveRegisterOperator(Model model, //
            @ModelAttribute("userForm") @Validated OperatorForm userForm, //
            BindingResult result, //
            final RedirectAttributes redirectAttributes) {
        // Validate result
        if (result.hasErrors()) {
            List<Roles> roles = roleService.getAllRoles().stream().filter(r -> r.getRoleName().equals("ROLE_OPER")).collect(Collectors.toList());
            model.addAttribute("roles", roles);
            model.addAttribute("info", msg.get("register.oper.new"));
            model.addAttribute("action", "/admin/register/operator");
            return "admin/registerPage";
        }
        String error = operService.createOperator(userForm);
        if (error != null && !error.isEmpty()) {
            List<Roles> roles = roleService.getAllRoles().stream().filter(r -> r.getRoleName().equals("ROLE_OPER")).collect(Collectors.toList());
            model.addAttribute("roles", roles);
            model.addAttribute("info", msg.get("register.oper.new"));
            model.addAttribute("action", "/admin/register/operator");
            model.addAttribute("errorMessage", error);
            return "admin/registerPage";
        }
        Users user = userService.getUserByLogin(userForm.getLogin());
        redirectAttributes.addFlashAttribute("flashUser", user);

        return "redirect:/admin/registerSuccessful";
    }

    @RequestMapping(value = "/admin/client/{login}", method = RequestMethod.GET)
    public String getClient(@PathVariable String login, Model model, Principal principal) {
        Client client = null;
        if (login != null && !login.isEmpty()) {
            client = clientService.getClient(login);
            ClientForm form = new ClientForm();
            if (client != null) {
                form.setFirstName(client.getFirstName());
                form.setLastName(client.getLastName());
                form.setLogin(client.getLogin());
                form.setPhone(client.getPhone());
                form.setDocument(client.getDocument());
                form.setNote(client.getNote());
                form.setOld(true);
                model.addAttribute("clientForm", form);
            }
        }
        return "admin/client";
    }

    @RequestMapping(value = "/admin/clients", method = RequestMethod.GET)
    public String getClients(@RequestParam(name = "page", required = false, defaultValue = "1") int page,
            Model model) {
        if (page <= 0) {
            page = 1;
        }
        List<Client> clients = clientService.getClients(page - 1, onPage, null);
        int prev = page;
        if (page > 1) {
            prev--;
            model.addAttribute("prev", prev);
        }
        int next = page;
        next++;
        model.addAttribute("next", next);
        model.addAttribute("clients", clients);
        model.addAttribute("page", page);
        return "admin/clients";
    }

    @RequestMapping(value = "/admin/operator/{login}", method = RequestMethod.GET)
    public String getOperator(@PathVariable String login, Model model, Principal principal) {
        Operator oper = null;
        if (login != null && !login.isEmpty()) {
            oper = operService.getOperator(login);
            OperatorForm form = new OperatorForm();
            if (oper != null) {
                form.setFirstName(oper.getFirstName());
                form.setLastName(oper.getLastName());
                form.setLogin(oper.getLogin());
                form.setPhone(oper.getPhone());
                form.setNote(oper.getNote());
                form.setOld(true);
                model.addAttribute("operForm", form);
            }
        }
        return "admin/operator";
    }

    @RequestMapping(value = "/admin/operator", method = RequestMethod.POST)
    public String updateClient(Model model, Principal principal,
            @ModelAttribute("operForm") @Validated OperatorForm operForm, //
            BindingResult result, //
            final RedirectAttributes redirectAttributes) {
        Operator oper = operService.getOperator(operForm.getLogin());
        if (result.hasErrors()) {
            operForm.setFirstName(oper.getFirstName());
            operForm.setLastName(oper.getLastName());
            operForm.setLogin(oper.getLogin());
            operForm.setPhone(oper.getPhone());
            operForm.setNote(oper.getNote());
            operForm.setOld(true);
            model.addAttribute("operForm", operForm);
            return "admin/operator";
        }
        String error = operService.updateOperator(operForm);
        oper = operService.getOperator(operForm.getLogin());

        if (error != null && !error.isEmpty()) {
            model.addAttribute("errorMessage", error);
            operForm.setFirstName(oper.getFirstName());
            operForm.setLastName(oper.getLastName());
            operForm.setLogin(oper.getLogin());
            operForm.setPhone(oper.getPhone());
            operForm.setNote(oper.getNote());
            operForm.setOld(true);
            return "admin/operator";
        }
        model.addAttribute("msg", msg.get("saved"));
        return "/admin/operator";
    }

    @RequestMapping(value = "/admin/operators", method = RequestMethod.GET)
    public String getOperators(@RequestParam(name = "page", required = false, defaultValue = "1") int page,
            Model model) {
        if (page <= 0) {
            page = 1;
        }
        int prev = page;
        if (page > 1) {
            prev--;
            model.addAttribute("prev", prev);
        }
        int next = page;
        next++;

        List<Operator> opers = operService.getOperators(page - 1, onPage);
        model.addAttribute("next", next);
        model.addAttribute("operators", opers);
        model.addAttribute("page", page);
        return "admin/operators";
    }

    @RequestMapping(value = "/admin/client", method = RequestMethod.POST)
    public String updateClient(Model model, Principal principal,
            @ModelAttribute("clientForm") @Validated ClientForm clientForm, //
            BindingResult result, //
            final RedirectAttributes redirectAttributes) {
        Client client = clientService.getClient(clientForm.getLogin());

        if (result.hasErrors()) {
            model.addAttribute("client", client);
            return "admin/client";
        }
        String error = clientService.updateClient(clientForm.getLogin(),
                clientForm.getLastName(), clientForm.getFirstName(), clientForm.getPhone(),
                clientForm.getDocument(), clientForm.getNote());
        client = clientService.getClient(clientForm.getLogin());

        if (error != null && !error.isEmpty()) {
            model.addAttribute("errorMessage", error);
            model.addAttribute("client", client);
            return "admin/client";
        }
        model.addAttribute("msg", msg.get("saved"));
        return "/admin/client";
    }

    @RequestMapping(value = "/admin/film", method = RequestMethod.GET)
    public String newFilm(Model model, @RequestParam(name = "id", required = false, defaultValue = "1") int id) {
        
        FilmForm film = new FilmForm();
        List<Producer> producer = producers.findAll();
        List<Actor> actor = actors.findAll();
        List<Country> country = countris.findAll();
        List<Category> category = categories.findAll();
        List<Ganre> ganres = this.ganres.findAll();
        if (id>0){
            Film f = films.findById(id).orElse(null);
            if (f!=null){
                film.setId(f.getId());
                film.setName(f.getName());
                film.setPoster(f.getPoster());
                film.setYear(f.getYear());
                film.setPath(f.getPoster());
                film.setProducer(f.getProducer().getId());
                film.setGanre(f.getGanre().getName());
                film.setCountry(f.getCountry().getCode());
                film.setCategory(f.getCategory().getCode());
                film.setAviable(f.getAviable());
                film.setNote(f.getNote());
                f.getActors().forEach(a->{
                    film.getActors().add(a.getId());
                });
            }
        }
        model.addAttribute("film", film);
        model.addAttribute("producers", producer);
        model.addAttribute("actors", actor);
        model.addAttribute("countries", country);
        model.addAttribute("categories",category);
        model.addAttribute("ganres",ganres);
        return "admin/film";
        
    }

    @RequestMapping(value = "/admin/film", method = RequestMethod.POST)
    public String saveFilm(Model model, @ModelAttribute("film") FilmForm film,
            BindingResult result) {

        Film saved =  filmService.save(film);
        if (saved==null){
        List<Producer> producer = producers.findAll();
        List<Actor> actor = actors.findAll();
        List<Country> country = countris.findAll();
        List<Category> category = categories.findAll();
        List<Ganre> ganres = this.ganres.findAll();
        model.addAttribute("film", film);
        model.addAttribute("producers", producer);
        model.addAttribute("actors", actor);
        model.addAttribute("countries", country);
        model.addAttribute("categories",category);
        model.addAttribute("ganres",ganres);
        return "admin/film";
        }
        return "redirect:/admin/films";
    }
    
    
    @RequestMapping(value = "/admin/films", method = {RequestMethod.GET, RequestMethod.POST})
    public String getFilms(
            Model model, @RequestParam(name = "page", required = false, defaultValue = "1") int page,
            HttpServletRequest request) {
        if (page <= 0) {
            page = 1;
        }
        int prev = page;
        if (prev > 1) {
            prev--;
            model.addAttribute("prev", prev);
        }
        int next = page;
        next++;
        model.addAttribute("next", next);
        model.addAttribute("page", page);
        List<Film> list = filmService.getAviable(page-1);
        model.addAttribute("films", list);
        return "admin/films";
    }
    
    @RequestMapping(value = "/admin/upload", method = RequestMethod.POST)
    @ResponseBody
    public ResponseEntity<?> handleFileUpload(
            @RequestParam("file") MultipartFile file,
            Model model) {
        String uploadsDir = "/uploads/";

        String realPathtoUploads = request.getServletContext().getRealPath(uploadsDir);
        if (!new File(realPathtoUploads).exists()) {
            new File(realPathtoUploads).mkdir();
        }

        String orgName = file.getOriginalFilename();


        String ext = FilenameUtils.getExtension(orgName);
        if (ext == null || ext.isEmpty()) {
            ext = "jpg";
        }
        String newName = UUID.randomUUID().toString() + "." + ext;
        String filePath = realPathtoUploads + newName;
        //orgName;
        File dest = new File(filePath);

        if (!file.isEmpty()) {
            try {
                file.transferTo(dest);
                /*byte[] bytes = file.getBytes();
                BufferedOutputStream stream =
                        new BufferedOutputStream(new FileOutputStream(new File("/uploads/"+name)));
                stream.write(bytes);
                stream.close();*/
                return new ResponseEntity<String>("/uploads/" + newName, HttpStatus.OK);
                //turn "Р’С‹ СѓРґР°С‡РЅРѕ Р·Р°РіСЂСѓР·РёР»Рё " + name + " РІ " + name + "-uploaded !";
            } catch (Exception e) {
                return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.BAD_REQUEST);
            }
        } else {
            return new ResponseEntity<>("Error: Empty File", HttpStatus.BAD_REQUEST);
        }
    }
    

}

