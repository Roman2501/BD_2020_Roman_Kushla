/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.movie.mvc;

import com.movie.entity.Cash;
import com.movie.entity.Rent;
import com.movie.entity.Roles;
import com.movie.entity.Users;
import com.movie.form.ClientForm;
import com.movie.form.PasswordForm;
import com.movie.form.RentForm;
import com.movie.service.ClientService;
import com.movie.service.RoleService;
import com.movie.service.UserService;
import com.movie.util.Messages;
import com.movie.validator.ClientValidator;
import com.movie.validator.PasswordValidator;
import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 *
 * @author Root
 */
@Controller
public class ClientController {
    int onPage = 25;
    String searchStr;
    
    @Autowired     UserService userService;
    @Autowired     ClientService clientService;
    @Autowired     RoleService roleService;
    @Autowired  
    private HttpServletRequest request;
    @Autowired     ServletContext context; 
    @Autowired       Messages msg;

    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    
    @Autowired
    ClientValidator clientValidator;
    @Autowired
    PasswordValidator passwordValidator;

    private static final Logger logger = LoggerFactory.getLogger(ClientController.class);

    @InitBinder
    protected void initBinder(WebDataBinder dataBinder) {

        Object target = dataBinder.getTarget();
        if (target == null) {
            return;
        }
      
        if (target.getClass() == ClientForm.class) {
            dataBinder.setValidator(clientValidator);
        }

        if (target.getClass() == PasswordForm.class) {
            dataBinder.setValidator(passwordValidator);
        }
        dateFormat.setLenient(false);
        dataBinder.registerCustomEditor(Date.class, null, new CustomDateEditor(dateFormat, true));
    }
    
    
     @RequestMapping(value = "/", method = RequestMethod.GET)
    public String index(Model model) {
        return "/index";
    }
     @RequestMapping(value = "/register", method = RequestMethod.GET)
    public String newRegisterClient(Model model) {

        ClientForm form = new ClientForm();
        model.addAttribute("info", msg.get("register.client.new"));
        model.addAttribute("userForm", form);
        return "/registerPage";
    }

    @RequestMapping(value = "/register", method = RequestMethod.POST)
    public String saveRegisterClient(Model model, //
            @ModelAttribute("userForm") @Validated ClientForm userForm, //
            BindingResult result, //
            final RedirectAttributes redirectAttributes) {
        // Validate result
        if (result.hasErrors()) {
             model.addAttribute("info", msg.get("register.client.new"));
            return "/registerPage";
        }
         Roles role = roleService.getRoleByName("ROLE_USER");
         userForm.setRole(role.getRoleName());
        String error = clientService.createClient(userForm);
        if (error != null && !error.isEmpty()) {
            model.addAttribute("errorMessage", error);
            model.addAttribute("info", msg.get("register.client.new"));
            return "/registerPage";
        }
        Users user = userService.getUserByLogin(userForm.getLogin());
        model.addAttribute("login", user.getLogin());
        return "/registerSuccessPage";
    }
    
     @RequestMapping(value = "/resetPassword", method = RequestMethod.GET)
    public String ressetPassword(Model model, Principal principal) {
        String login = principal.getName();
        PasswordForm form = new PasswordForm(login);
        model.addAttribute("passForm", form);
        return "resetPassword";
    }

    @RequestMapping(value = "/resetPassword", method = RequestMethod.POST)
    public String ressetingPassword(Model model, //
            @ModelAttribute("passForm") @Validated PasswordForm passForm, //
            BindingResult result, //
            final RedirectAttributes redirectAttributes) {
        // Validate result
        if (result.hasErrors()) {
            return "resetPassword";
        }
        String error = userService.resetPassword(passForm.getLogin(), passForm.getPassword());
        if (error != null && !error.isEmpty()) {
            model.addAttribute("errorMessage", error);
            return "resetPassword";
        }
        return "redirect:/logout";
    }
    
     
    @RequestMapping(value = "/rent/{id}", method = { RequestMethod.GET})
    public String getRentById(Model model, Principal principal,@PathVariable long id)
    {
         Rent rents =  clientService.getRentByID(id).orElse(null);
         if (rents!=null && rents.getReturnDate()==null){
             RentForm form = new RentForm(rents);
             model.addAttribute("rentForm", form);
         }
         model.addAttribute("rent", rents);
         return "rent";
    }
    
    
    @RequestMapping(value = "/rents", method = { RequestMethod.GET})
    public String getActiveRents(Model model, Principal principal, @RequestParam(name = "page", required = false, defaultValue = "1") int page)
    {
        if (page <= 0) {
            page = 1;
        }
         int prev = page;
         if (prev > 1) {
             prev--;
            model.addAttribute("prev", prev);
         }
         int next = page;
         next++;
         model.addAttribute("next", next);
         model.addAttribute("page", page);
         List<Rent> rents =  clientService.getActiveRentByClint(principal.getName());
         model.addAttribute("rents", rents);
         model.addAttribute("action", "rents");
         return "rents";
    }
    
    @RequestMapping(value = "/rents/all", method = { RequestMethod.GET})
    public String getAllRents(Model model, Principal principal, 
            @RequestParam(name = "page", required = false, defaultValue = "1") int page)
    {
         if (page <= 0) {
            page = 1;
        }
         int prev = page;
         if (prev > 1) {
             prev--;
            model.addAttribute("prev", prev);
         }
         int next = page;
         next++;
         model.addAttribute("next", next);
         model.addAttribute("page", page);
         model.addAttribute("action", "rents/all");
         List<Rent> rents =  clientService.getAllRentByClient(page-1,onPage,principal.getName());
         model.addAttribute("rents", rents);
         return "rents";
    }


    
}
